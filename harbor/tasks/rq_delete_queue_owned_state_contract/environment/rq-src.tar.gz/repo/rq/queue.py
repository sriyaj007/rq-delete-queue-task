from __future__ import annotations

import logging
import sys
import uuid
import warnings
from collections import defaultdict, namedtuple
from collections.abc import Callable, Iterable, Sequence
from datetime import datetime, timedelta
from functools import total_ordering
from typing import (
    TYPE_CHECKING,
    Any,
    NamedTuple,
    cast,
)

from redis import WatchError

from .timeouts import BaseDeathPenalty, UnixSignalDeathPenalty

if TYPE_CHECKING:
    from redis import Redis
    from redis.client import Pipeline

    from .job import Retry

from .callbacks import Callback, execute_failure_callback, execute_success_callback
from .defaults import DEFAULT_RESULT_TTL, RQ_KEY_PREFIX
from .dependency import Dependency
from .exceptions import DequeueTimeout, NoSuchJobError
from .intermediate_queue import IntermediateQueue
from .job import Job, JobStatus
from .job_lifecycle import format_exc_info, record_job_failure
from .logutils import blue, green
from .rate_limit import RateLimit, RateLimitRegistry
from .repeat import Repeat
from .scripts import save_unique_job, schedule_unique_job
from .serializers import Serializer, resolve_serializer
from .types import FunctionReferenceType, JobDependencyType
from .utils import as_text, backend_class, compact, get_version, import_attribute, now, parse_timeout
from .webhook import Webhook

logger = logging.getLogger('rq.queue')


class EnqueueData(
    namedtuple(
        'EnqueueData',
        [
            'func',
            'args',
            'kwargs',
            'timeout',
            'result_ttl',
            'ttl',
            'failure_ttl',
            'description',
            'depends_on',
            'job_id',
            'at_front',
            'meta',
            'retry',
            'on_success',
            'on_failure',
            'on_stopped',
            'repeat',
            'webhooks',
        ],
    )
):
    """Helper type to use when calling enqueue_many
    NOTE: Does not support `depends_on` yet.
    """

    __slots__ = ()


class EnqueueArgs(NamedTuple):
    """Helper type to use when calling Queue.parse_args"""

    func: str | Callable[..., Any]
    timeout: int | str | None
    description: str | None
    result_ttl: int | None
    ttl: int | None
    failure_ttl: int | None
    depends_on: JobDependencyType | None
    job_id: str | None
    at_front: bool
    meta: dict | None
    retry: Retry | None
    repeat: Repeat | None
    on_success: Callback | Callable | None
    on_failure: Callback | Callable | None
    on_stopped: Callback | Callable | None
    rate_limit: RateLimit | None
    pipeline: Pipeline | None
    unique: bool
    args: tuple | list | None
    kwargs: dict | None
    webhooks: Sequence[Webhook] | None


@total_ordering
class Queue:
    job_class: type[Job] = Job
    death_penalty_class: type[BaseDeathPenalty] = UnixSignalDeathPenalty
    DEFAULT_TIMEOUT: int = 180  # Default timeout seconds.
    redis_queue_namespace_prefix: str = RQ_KEY_PREFIX + ':queue:'
    redis_queues_keys: str = RQ_KEY_PREFIX + ':queues'

    @classmethod
    def all(
        cls,
        connection: Redis,
        job_class: type[Job] | None = None,
        serializer=None,
        death_penalty_class: type[BaseDeathPenalty] | None = None,
    ) -> list[Queue]:
        """Returns an iterable of all Queues.

        Args:
            connection (Optional[Redis], optional): The Redis Connection. Defaults to None.
            job_class (Optional[Job], optional): The Job class to use. Defaults to None.
            serializer (optional): The serializer to use. Defaults to None.
            death_penalty_class (Optional[Job], optional): The Death Penalty class to use. Defaults to None.

        Returns:
            queues (List[Queue]): A list of all queues.
        """

        def to_queue(queue_key: bytes | str):
            return cls.from_queue_key(
                as_text(queue_key),
                connection=connection,
                job_class=job_class,
                serializer=serializer,
                death_penalty_class=death_penalty_class,
            )

        all_registered_queues = connection.smembers(cls.redis_queues_keys)
        all_queues = [to_queue(rq_key) for rq_key in all_registered_queues if rq_key]
        return all_queues

    @classmethod
    def from_queue_key(
        cls,
        queue_key: str,
        connection: Redis,
        job_class: type[Job] | None = None,
        serializer: Serializer | str | None = None,
        death_penalty_class: type[BaseDeathPenalty] | None = None,
    ) -> Queue:
        """Returns a Queue instance, based on the naming conventions for naming
        the internal Redis keys.  Can be used to reverse-lookup Queues by their
        Redis keys.

        Args:
            queue_key (str): The queue key
            connection (Redis): Redis connection. Defaults to None.
            job_class (Optional[Job], optional): Job class. Defaults to None.
            serializer (Optional[Union[Serializer, str]], optional): Serializer. Defaults to None.
            death_penalty_class (Optional[BaseDeathPenalty], optional): Death penalty class. Defaults to None.

        Raises:
            ValueError: If the queue_key doesn't start with the defined prefix

        Returns:
            queue (Queue): The Queue object
        """
        prefix = cls.redis_queue_namespace_prefix
        if not queue_key.startswith(prefix):
            raise ValueError(f'Not a valid RQ queue key: {queue_key}')
        name = queue_key[len(prefix) :]
        return cls(
            name,
            connection=connection,
            job_class=job_class,
            serializer=serializer,
            death_penalty_class=death_penalty_class,
        )

    def __init__(
        self,
        name: str = 'default',
        connection: Redis | None = None,
        default_timeout: int | None = None,
        is_async: bool = True,
        job_class: str | type[Job] | None = None,
        serializer: Serializer | str | None = None,
        death_penalty_class: type[BaseDeathPenalty] | None = UnixSignalDeathPenalty,
        **kwargs,
    ):
        """Initializes a Queue object.

        Args:
            name (str, optional): The queue name. Defaults to 'default'.
            default_timeout (Optional[int], optional): Queue's default timeout. Defaults to None.
            connection (Optional[Redis], optional): Redis connection. Defaults to None.
            is_async (bool, optional): Whether jobs should run "async" (using the worker).
                If `is_async` is false, jobs will run on the same process from where it was called. Defaults to True.
            job_class (Union[str, 'Job', optional): Job class or a string referencing the Job class path.
                Defaults to None.
            serializer (Optional[Union[Serializer, str]], optional): Serializer. Defaults to None.
            death_penalty_class (Type[BaseDeathPenalty, optional): Job class or a string referencing the Job class path.
                Defaults to UnixSignalDeathPenalty.
        """
        if not connection:
            raise TypeError("Queue() missing 1 required positional argument: 'connection'")
        self.connection = connection
        prefix = self.redis_queue_namespace_prefix
        self.name = name
        self._key = f'{prefix}{name}'
        self._default_timeout = parse_timeout(default_timeout) or self.DEFAULT_TIMEOUT
        self._is_async = is_async
        self.log = logger

        if 'async' in kwargs:
            self._is_async = kwargs['async']
            warnings.warn('The `async` keyword is deprecated. Use `is_async` instead', DeprecationWarning)

        # override class attribute job_class if one was passed
        if job_class is not None:
            if isinstance(job_class, str):
                self.job_class = import_attribute(job_class)  # type: ignore[assignment]
            else:
                self.job_class = job_class
        self.death_penalty_class = death_penalty_class  # type: ignore[assignment]

        self.serializer = resolve_serializer(serializer)
        self.redis_server_version: tuple[int, int, int] | None = None

    def __len__(self):
        return self.count

    def __bool__(self):
        return True

    def __iter__(self):
        yield self

    def get_redis_server_version(self) -> tuple[int, int, int]:
        """Return Redis server version of connection

        Returns:
            redis_version (Tuple): A tuple with the parsed Redis version (eg: (5,0,0))
        """
        if not self.redis_server_version:
            self.redis_server_version = get_version(self.connection)
        return self.redis_server_version

    @property
    def key(self):
        """Returns the Redis key for this Queue."""
        return self._key

    @property
    def intermediate_queue_key(self):
        """Returns the Redis key for intermediate queue."""
        return IntermediateQueue.get_intermediate_queue_key(self._key)

    @property
    def intermediate_queue(self) -> IntermediateQueue:
        """Returns the IntermediateQueue instance for this Queue."""
        return IntermediateQueue(self.key, connection=self.connection)

    @property
    def registry_cleaning_key(self):
        """Redis key used to indicate this queue has been cleaned."""
        return f'{RQ_KEY_PREFIX}:clean_registries:{self.name}'

    @property
    def scheduler_pid(self) -> int | None:
        from rq.scheduler import SCHEDULER_KEY_TEMPLATE, RQScheduler

        name = self.connection.get(RQScheduler.get_locking_key(self.name))
        if name is None:
            return None
        pid = self.connection.hget(SCHEDULER_KEY_TEMPLATE % name.decode(), 'pid')
        return int(pid) if pid else None

    def acquire_maintenance_lock(self) -> bool:
        """Returns a boolean indicating whether a lock to clean this queue
        is acquired. A lock expires in 899 seconds (15 minutes - 1 second)

        Returns:
            lock_acquired (bool)
        """
        lock_acquired = self.connection.set(self.registry_cleaning_key, 1, nx=True, ex=899)
        if not lock_acquired:
            return False
        return lock_acquired

    def release_maintenance_lock(self):
        """Deletes the maintenance lock after registries have been cleaned"""
        self.connection.delete(self.registry_cleaning_key)

    def empty(self):
        """Removes all messages on the queue.
        This is currently being done using a Lua script,
        which iterates all queue messages and deletes the jobs and it's dependents.
        It registers the Lua script and calls it.
        Even though is currently being returned, this is not strictly necessary.

        Returns:
            script (...): The Lua Script is called.
        """
        from .results import Result

        script = f"""
            local prefix = "{self.job_class.redis_job_namespace_prefix}"
            local result_prefix = "{Result.get_key('')}"
            local q = KEYS[1]
            local count = 0
            while true do
                local job_id = redis.call("lpop", q)
                if job_id == false then
                    break
                end

                -- Delete the relevant keys
                redis.call("del", prefix..job_id, result_prefix..job_id)
                redis.call("del", prefix..job_id..":dependents")
                count = count + 1
            end
            return count
        """.encode()
        script = self.connection.register_script(script)
        return script(keys=[self.key])

    def delete(self, delete_jobs: bool = True):
        """Deletes the queue.

        Args:
            delete_jobs (bool): If true, removes all the associated messages on the queue first.
        """
        if delete_jobs:
            self.empty()

        with self.connection.pipeline() as pipeline:
            pipeline.srem(self.redis_queues_keys, self._key)
            pipeline.delete(self._key)
            pipeline.execute()

    def is_empty(self) -> bool:
        """Returns whether the current queue is empty.

        Returns:
            is_empty (bool): Whether the queue is empty
        """
        return self.count == 0

    @property
    def is_async(self) -> bool:
        """Returns whether the current queue is async."""
        return bool(self._is_async)

    def fetch_job(self, job_id: str) -> Job | None:
        """Fetch a single job by Job ID.
        If the job key is not found, will run the `remove` method, to exclude the key.
        If the job has the same name as as the current job origin, returns the Job

        Args:
            job_id (str): The Job ID

        Returns:
            job (Optional[Job]): The job if found
        """
        try:
            job = self.job_class.fetch(job_id, connection=self.connection, serializer=self.serializer)
        except NoSuchJobError:
            self.remove(job_id)
        else:
            if job.origin == self.name:
                return job

        return None

    def get_job_position(self, job_or_id: Job | str) -> int | None:
        """Returns the position of a job within the queue

        Using Redis before 6.0.6 and redis-py before 3.5.4 has a complexity of
        worse than O(N) and should not be used for very long job queues. Redis
        and redis-py version afterwards should support the LPOS command
        handling job positions within Redis c implementation.

        Args:
            job_or_id (Union[Job, str]): The Job instance or Job ID

        Returns:
            _type_: _description_
        """
        job_id = cast(str, job_or_id.id if isinstance(job_or_id, self.job_class) else job_or_id)

        if self.get_redis_server_version() >= (6, 0, 6):
            try:
                return self.connection.lpos(self.key, job_id)
            except AttributeError:
                # not yet implemented by redis-py
                pass

        if job_id in self.job_ids:
            return self.job_ids.index(job_id)
        return None

    def get_job_ids(self, offset: int = 0, length: int = -1) -> list[str]:
        """Returns a slice of job IDs in the queue.

        A length of 0 returns an empty list.

        Args:
            offset (int, optional): The offset. Defaults to 0.
            length (int, optional): The slice length. Defaults to -1 (last element).

        Returns:
            _type_: _description_
        """
        if length == 0:
            return []

        start = offset
        if length >= 0:
            end = offset + (length - 1)
        else:
            end = length
        job_ids = [as_text(job_id) for job_id in self.connection.lrange(self.key, start, end)]
        self.log.debug('Getting jobs for queue %s: %d found.', green(self.name), len(job_ids))
        return job_ids

    def get_jobs(self, offset: int = 0, length: int = -1) -> list[Job]:
        """Returns a slice of jobs in the queue.

        Args:
            offset (int, optional): The offset. Defaults to 0.
            length (int, optional): The slice length. Defaults to -1.

        Returns:
            _type_: _description_
        """
        job_ids = self.get_job_ids(offset, length)
        return compact([self.fetch_job(job_id) for job_id in job_ids])

    @property
    def job_ids(self) -> list[str]:
        """Returns a list of all job IDS in the queue."""
        return self.get_job_ids()

    @property
    def jobs(self) -> list[Job]:
        """Returns a list of all (valid) jobs in the queue."""
        return self.get_jobs()

    @property
    def count(self) -> int:
        """Returns a count of all messages in the queue."""
        return self.connection.llen(self.key)

    @property
    def failed_job_registry(self):
        """Returns this queue's FailedJobRegistry."""
        from rq.registry import FailedJobRegistry

        return FailedJobRegistry(queue=self, job_class=self.job_class, serializer=self.serializer)

    @property
    def started_job_registry(self):
        """Returns this queue's StartedJobRegistry."""
        from rq.registry import StartedJobRegistry

        return StartedJobRegistry(queue=self, job_class=self.job_class, serializer=self.serializer)

    @property
    def finished_job_registry(self):
        """Returns this queue's FinishedJobRegistry."""
        from rq.registry import FinishedJobRegistry

        # TODO: Why was job_class only omitted here before?  Was it intentional?
        return FinishedJobRegistry(queue=self, job_class=self.job_class, serializer=self.serializer)

    @property
    def deferred_job_registry(self):
        """Returns this queue's DeferredJobRegistry."""
        from rq.registry import DeferredJobRegistry

        return DeferredJobRegistry(queue=self, job_class=self.job_class, serializer=self.serializer)

    @property
    def ready_job_registry(self):
        """Returns this queue's ReadyJobRegistry."""
        from rq.registry import ReadyJobRegistry

        return ReadyJobRegistry(queue=self, job_class=self.job_class, serializer=self.serializer)

    @property
    def scheduled_job_registry(self):
        """Returns this queue's ScheduledJobRegistry."""
        from rq.registry import ScheduledJobRegistry

        return ScheduledJobRegistry(queue=self, job_class=self.job_class, serializer=self.serializer)

    @property
    def canceled_job_registry(self):
        """Returns this queue's CanceledJobRegistry."""
        from rq.registry import CanceledJobRegistry

        return CanceledJobRegistry(queue=self, job_class=self.job_class, serializer=self.serializer)

    def remove(self, job_or_id: Job | str, pipeline: Pipeline | None = None):
        """Removes Job from queue, accepts either a Job instance or ID.

        Args:
            job_or_id (Union[Job, str]): The Job instance or Job ID string.
            pipeline (Optional[Pipeline], optional): The Redis Pipeline. Defaults to None.

        Returns:
            _type_: _description_
        """
        job_id = cast(str, job_or_id.id if isinstance(job_or_id, self.job_class) else job_or_id)

        if pipeline is not None:
            return pipeline.lrem(self.key, 1, job_id)

        return self.connection.lrem(self.key, 1, job_id)

    def compact(self):
        """Removes all "dead" jobs from the queue by cycling through it,
        while guaranteeing FIFO semantics.
        """
        COMPACT_QUEUE = f'{self.redis_queue_namespace_prefix}_compact:{uuid.uuid4()}'  # noqa

        self.connection.rename(self.key, COMPACT_QUEUE)
        while True:
            job_id = self.connection.lpop(COMPACT_QUEUE)
            if job_id is None:
                break
            if self.job_class.exists(as_text(job_id), self.connection):
                self.connection.rpush(self.key, job_id)

    def push_job_id(self, job_id: str, pipeline: Pipeline | None = None, at_front: bool = False):
        """Pushes a job ID on the corresponding Redis queue.
        'at_front' allows you to push the job onto the front instead of the back of the queue

        Args:
            job_id (str): The Job ID
            pipeline (Optional[Pipeline], optional): The Redis Pipeline to use. Defaults to None.
            at_front (bool, optional): Whether to push the job to front of the queue. Defaults to False.
        """
        connection = pipeline if pipeline is not None else self.connection
        push = connection.lpush if at_front else connection.rpush
        result = push(self.key, job_id)
        if pipeline is None:
            self.log.debug('Pushed job %s into %s, %s job(s) are in queue.', blue(job_id), green(self.name), result)
        else:
            # Pipelines do not return the number of jobs in the queue.
            self.log.debug('Pushed job %s into %s', blue(job_id), green(self.name))

    def create_job(
        self,
        func: FunctionReferenceType,
        args: tuple | list | None = None,
        kwargs: dict | None = None,
        timeout: int | None = None,
        result_ttl: int | None = None,
        ttl: int | None = None,
        failure_ttl: int | None = None,
        description: str | None = None,
        depends_on: JobDependencyType | None = None,
        job_id: str | None = None,
        meta: dict | None = None,
        status: JobStatus = JobStatus.QUEUED,
        retry: Retry | None = None,
        repeat: Repeat | None = None,
        *,
        on_success: Callback | Callable | None = None,
        on_failure: Callback | Callable | None = None,
        on_stopped: Callback | Callable | None = None,
        webhooks: Sequence[Webhook] | None = None,
        group_id: str | None = None,
        rate_limit: RateLimit | None = None,
    ) -> Job:
        """Creates a job based on parameters given

        Args:
            func (FunctionReferenceType): The function reference: a callable or the path.
            args (Union[Tuple, List, None], optional): The `*args` to pass to the function. Defaults to None.
            kwargs (Optional[Dict], optional): The `**kwargs` to pass to the function. Defaults to None.
            timeout (Optional[int], optional): Function timeout. Defaults to None, use -1 for infinite timeout.
            result_ttl (Optional[int], optional): Result time to live. Defaults to None.
            ttl (Optional[int], optional): Time to live. Defaults to None.
            failure_ttl (Optional[int], optional): Failure time to live. Defaults to None.
            description (Optional[str], optional): The description. Defaults to None.
            depends_on (Optional[JobDependencyType], optional): The job dependencies. Defaults to None.
            job_id (Optional[str], optional): Job ID. Defaults to None.
            meta (Optional[Dict], optional): Job metadata. Defaults to None.
            status (JobStatus, optional): Job status. Defaults to JobStatus.QUEUED.
            retry (Optional[Retry], optional): The Retry Object. Defaults to None.
            repeat (Optional[Repeat], optional): The Repeat Object. Defaults to None.
            on_success (Optional[Union[Callback, Callable[..., Any]]], optional): Callback for on success. Defaults to
                None. Callable is deprecated.
            on_failure (Optional[Union[Callback, Callable[..., Any]]], optional): Callback for on failure. Defaults to
                None. Callable is deprecated.
            on_stopped (Optional[Union[Callback, Callable[..., Any]]], optional): Callback for on stopped. Defaults to
                None. Callable is deprecated.
            webhooks (Optional[Sequence[Webhook]], optional): Webhooks to send on matching terminal job statuses.
                Defaults to None.
            group_id (Optional[str], optional): A group ID that the job is being added to. Defaults to None.

        Raises:
            ValueError: If the timeout is 0
            ValueError: If the job TTL is 0 or negative

        Returns:
            Job: The created job
        """
        timeout = parse_timeout(timeout)

        if timeout is None:
            timeout = self._default_timeout
        elif timeout == 0:
            raise ValueError('0 timeout is not allowed. Use -1 for infinite timeout')

        result_ttl = parse_timeout(result_ttl)
        failure_ttl = parse_timeout(failure_ttl)

        ttl = parse_timeout(ttl)
        if ttl is not None and ttl <= 0:
            raise ValueError('Job ttl must be greater than 0')

        job = self.job_class.create(
            func,
            args=args,
            kwargs=kwargs,
            connection=self.connection,
            result_ttl=result_ttl,
            ttl=ttl,
            failure_ttl=failure_ttl,
            status=status,
            description=description,
            depends_on=depends_on,
            timeout=timeout,
            id=job_id,
            origin=self.name,
            meta=meta,
            serializer=self.serializer,
            on_success=on_success,
            on_failure=on_failure,
            on_stopped=on_stopped,
            webhooks=webhooks,
            group_id=group_id,
        )

        if retry:
            job.retries_left = retry.max
            job.retry_intervals = retry.intervals
            job.enqueue_at_front_on_retry = retry.enqueue_at_front

        if repeat:
            job.repeats_left = repeat.times
            job.repeat_intervals = repeat.intervals

        if rate_limit:
            job.rate_limit_key = rate_limit.key
            job.rate_limit_concurrency = rate_limit.concurrency

        return job

    def setup_dependencies(self, job: Job, pipeline: Pipeline | None = None) -> Job:
        """If a _dependent_ job depends on any unfinished job, register all the
        _dependent_ job's dependencies instead of enqueueing it.

        `Job#fetch_dependencies` sets WATCH on all dependencies. If
        WatchError is raised in the when the pipeline is executed, that means
        something else has modified either the set of dependencies or the
        status of one of them. In this case, we simply retry.

        Args:
            job (Job): The job
            pipeline (Optional[Pipeline], optional): The Redis Pipeline. Defaults to None.

        Returns:
            job (Job): The Job
        """
        if len(job._dependency_ids) > 0:
            orig_status = job.get_status(refresh=False)
            pipe = pipeline if pipeline is not None else self.connection.pipeline()
            while True:
                try:
                    # Also calling watch even if caller
                    # passed in a pipeline since Queue#create_job
                    # is called from within this method.
                    pipe.watch(job.dependencies_key)

                    dependencies = job.fetch_dependencies(watch=True, pipeline=pipe)

                    pipe.multi()

                    # As in Job.dependencies_are_met(), a failed dependency is met if the job allows failures
                    met_statuses = [JobStatus.FINISHED]
                    if job.allow_dependency_failures:
                        met_statuses.append(JobStatus.FAILED)

                    for dependency in dependencies:
                        if dependency.get_status(refresh=False) not in met_statuses:
                            # NOTE: If the following code changes local variables, those values probably have
                            # to be set back to their original values in the handling of WatchError below!
                            job.set_status(JobStatus.DEFERRED, pipeline=pipe)
                            job.register_dependency(pipeline=pipe)
                            job.save(pipeline=pipe)
                            job.cleanup(ttl=job.ttl, pipeline=pipe)
                            if pipeline is None:
                                pipe.execute()
                            return job
                    break
                except WatchError:
                    if pipeline is None:
                        # The call to job.set_status(JobStatus.DEFERRED, pipeline=pipe) above has changed the
                        # internal "_status". We have to reset it to its original value (probably QUEUED), so
                        # if during the next run no unfinished dependencies exist anymore, the job gets
                        # enqueued correctly by enqueue_call().
                        job._status = orig_status
                        continue
                    else:
                        # if pipeline comes from caller, re-raise to them
                        raise
        elif pipeline is not None:
            # Ensure pipeline in multi mode before returning to caller (if not set before)
            if not pipeline.explicit_transaction:
                pipeline.multi()
        return job

    def enqueue_call(
        self,
        func: FunctionReferenceType,
        args: tuple | list | None = None,
        kwargs: dict | None = None,
        timeout: int | None = None,
        result_ttl: int | None = None,
        ttl: int | None = None,
        failure_ttl: int | None = None,
        description: str | None = None,
        depends_on: JobDependencyType | None = None,
        job_id: str | None = None,
        at_front: bool = False,
        meta: dict | None = None,
        retry: Retry | None = None,
        repeat: Repeat | None = None,
        on_success: Callback | Callable[..., Any] | None = None,
        on_failure: Callback | Callable[..., Any] | None = None,
        on_stopped: Callback | Callable[..., Any] | None = None,
        rate_limit: RateLimit | None = None,
        pipeline: Pipeline | None = None,
        unique: bool = False,
        webhooks: Sequence[Webhook] | None = None,
    ) -> Job:
        """Creates a job to represent the delayed function call and enqueues it.

        It is much like `.enqueue()`, except that it takes the function's args
        and kwargs as explicit arguments.  Any kwargs passed to this function
        contain options for RQ itself.

        Args:
            func (FunctionReferenceType): The reference to the function
            args (Union[Tuple, List, None], optional): The `*args` to pass to the function. Defaults to None.
            kwargs (Optional[Dict], optional): The `**kwargs` to pass to the function. Defaults to None.
            timeout (Optional[int], optional): Function timeout. Defaults to None.
            result_ttl (Optional[int], optional): Result time to live. Defaults to None.
            ttl (Optional[int], optional): Time to live. Defaults to None.
            failure_ttl (Optional[int], optional): Failure time to live. Defaults to None.
            description (Optional[str], optional): The job description. Defaults to None.
            depends_on (Optional[JobDependencyType], optional): The job dependencies. Defaults to None.
            job_id (Optional[str], optional): The job ID. Defaults to None.
            at_front (bool, optional): Whether to enqueue the job at the front. Defaults to False.
            meta (Optional[Dict], optional): Metadata to attach to the job. Defaults to None.
            retry (Optional[Retry], optional): Retry object. Defaults to None.
            on_success (Optional[Union[Callback, Callable[..., Any]]], optional): Callback for on success. Defaults to
                None. Callable is deprecated.
            on_failure (Optional[Union[Callback, Callable[..., Any]]], optional): Callback for on failure. Defaults to
                None. Callable is deprecated.
            on_stopped (Optional[Union[Callback, Callable[..., Any]]], optional): Callback for on stopped. Defaults to
                None. Callable is deprecated.
            pipeline (Optional[Pipeline], optional): The Redis Pipeline. Defaults to None.
            unique (bool, optional): If True, raises DuplicateJobError if a job with the same ID exists.
                Defaults to False.
            webhooks (Optional[Sequence[Webhook]], optional): Webhooks to send on matching terminal job statuses.
                Defaults to None.

        Returns:
            Job: The enqueued Job
        """
        if unique and not job_id:
            raise ValueError('unique=True requires an explicit job_id')

        job = self.create_job(
            func,
            args=args,
            kwargs=kwargs,
            result_ttl=result_ttl,
            ttl=ttl,
            failure_ttl=failure_ttl,
            description=description,
            depends_on=depends_on,
            job_id=job_id,
            meta=meta,
            status=JobStatus.QUEUED,
            timeout=timeout,
            retry=retry,
            repeat=repeat,
            on_success=on_success,
            on_failure=on_failure,
            on_stopped=on_stopped,
            rate_limit=rate_limit,
            webhooks=webhooks,
        )
        return self.enqueue_job(job, pipeline=pipeline, at_front=at_front, unique=unique)

    @staticmethod
    def prepare_data(
        func: FunctionReferenceType,
        args: tuple | list | None = None,
        kwargs: dict | None = None,
        timeout: int | None = None,
        result_ttl: int | None = None,
        ttl: int | None = None,
        failure_ttl: int | None = None,
        description: str | None = None,
        depends_on: JobDependencyType | None = None,
        job_id: str | None = None,
        at_front: bool = False,
        meta: dict | None = None,
        retry: Retry | None = None,
        on_success: Callback | Callable | None = None,
        on_failure: Callback | Callable | None = None,
        on_stopped: Callback | Callable | None = None,
        repeat: Repeat | None = None,
        webhooks: Sequence[Webhook] | None = None,
    ) -> EnqueueData:
        """Need this till support dropped for python_version < 3.7, where defaults can be specified for named tuples
        And can keep this logic within EnqueueData

        Args:
            func (FunctionReferenceType): The reference to the function
            args (Union[Tuple, List, None], optional): The `*args` to pass to the function. Defaults to None.
            kwargs (Optional[Dict], optional): The `**kwargs` to pass to the function. Defaults to None.
            timeout (Optional[int], optional): Function timeout. Defaults to None.
            result_ttl (Optional[int], optional): Result time to live. Defaults to None.
            ttl (Optional[int], optional): Time to live. Defaults to None.
            failure_ttl (Optional[int], optional): Failure time to live. Defaults to None.
            description (Optional[str], optional): The job description. Defaults to None.
            depends_on (Optional[JobDependencyType], optional): The job dependencies. Defaults to None.
            job_id (Optional[str], optional): The job ID. Defaults to None.
            at_front (bool, optional): Whether to enqueue the job at the front. Defaults to False.
            meta (Optional[Dict], optional): Metadata to attach to the job. Defaults to None.
            retry (Optional[Retry], optional): Retry object. Defaults to None.
            on_success (Optional[Union[Callback, Callable[..., Any]]], optional): Callback for on success. Defaults to
                None. Callable is deprecated.
            on_failure (Optional[Union[Callback, Callable[..., Any]]], optional): Callback for on failure. Defaults to
                None. Callable is deprecated.
            on_stopped (Optional[Union[Callback, Callable[..., Any]]], optional): Callback for on stopped. Defaults to
                None. Callable is deprecated.
            repeat (Optional[Repeat], optional): Repeat object. Defaults to None.
            webhooks (Optional[Sequence[Webhook]], optional): Webhooks to send on matching terminal job statuses.
                Defaults to None.

        Returns:
            EnqueueData: The EnqueueData
        """
        return EnqueueData(
            func,
            args,
            kwargs,
            timeout,
            result_ttl,
            ttl,
            failure_ttl,
            description,
            depends_on,
            job_id,
            at_front,
            meta,
            retry,
            on_success,
            on_failure,
            on_stopped,
            repeat,
            webhooks,
        )

    def enqueue_many(
        self, job_datas: Iterable[EnqueueData], pipeline: Pipeline | None = None, group_id: str | None = None
    ) -> list[Job]:
        """Creates multiple jobs (created via `Queue.prepare_data` calls)
        to represent the delayed function calls and enqueues them.

        Args:
            job_datas (Iterable[EnqueueData]): An iterable of job data
            pipeline (Optional[Pipeline], optional): The Redis Pipeline. Defaults to None.

        Returns:
            List[Job]: A list of enqueued jobs
        """

        jobs_without_dependencies = []
        jobs_with_unmet_dependencies = []
        jobs_with_met_dependencies = []

        def get_job_kwargs(job_data, initial_status):
            return {
                'func': job_data.func,
                'args': job_data.args,
                'kwargs': job_data.kwargs,
                'result_ttl': job_data.result_ttl,
                'ttl': job_data.ttl,
                'failure_ttl': job_data.failure_ttl,
                'description': job_data.description,
                'depends_on': job_data.depends_on,
                'job_id': job_data.job_id,
                'meta': job_data.meta,
                'status': initial_status,
                'timeout': job_data.timeout,
                'retry': job_data.retry,
                'on_success': job_data.on_success,
                'on_failure': job_data.on_failure,
                'on_stopped': job_data.on_stopped,
                'webhooks': job_data.webhooks,
                'group_id': group_id,
                'repeat': job_data.repeat,
            }

        # Partition in one pass so that job_datas can be a one-shot iterable.
        job_datas_without_dependencies = []
        job_datas_with_dependencies = []
        job_ids = set()
        for job_data in job_datas:
            # Two entries with the same job_id would be saved to the same key, losing one of them
            if job_data.job_id is not None:
                if job_data.job_id in job_ids:
                    raise ValueError(f"Job ID '{job_data.job_id}' appears more than once in enqueue_many()")
                job_ids.add(job_data.job_id)
            if job_data.depends_on:
                job_datas_with_dependencies.append(job_data)
            else:
                job_datas_without_dependencies.append(job_data)

        pipe = pipeline if pipeline is not None else self.connection.pipeline()

        # Add Queue key set
        pipe.sadd(self.redis_queues_keys, self.key)

        # Enqueue jobs without dependencies
        if job_datas_without_dependencies:
            jobs_without_dependencies = [
                self._enqueue_job(
                    self.create_job(**get_job_kwargs(job_data, JobStatus.QUEUED)),
                    pipeline=pipe,
                    at_front=job_data.at_front,
                )
                for job_data in job_datas_without_dependencies
            ]
            if pipeline is None:
                pipe.execute()

        if job_datas_with_dependencies:
            # Save all jobs with dependencies as deferred
            jobs_with_dependencies = [
                self.create_job(**get_job_kwargs(job_data, JobStatus.DEFERRED))
                for job_data in job_datas_with_dependencies
            ]
            for job in jobs_with_dependencies:
                job.save(pipeline=pipe)
            if pipeline is None:
                pipe.execute()

            # Enqueue the jobs whose dependencies have been met
            at_front_job_ids = {
                job.id
                for job, job_data in zip(jobs_with_dependencies, job_datas_with_dependencies)
                if job_data.at_front
            }
            jobs_with_met_dependencies, jobs_with_unmet_dependencies = Dependency.get_jobs_with_met_dependencies(
                jobs_with_dependencies, pipeline=pipe
            )
            jobs_with_met_dependencies = [
                self._enqueue_job(job, pipeline=pipe, at_front=job.enqueue_at_front or job.id in at_front_job_ids)
                for job in jobs_with_met_dependencies
            ]
            # As in setup_dependencies(), deferred jobs expire after their ttl
            for job in jobs_with_unmet_dependencies:
                job.cleanup(ttl=job.ttl, pipeline=pipe)
            if pipeline is None:
                pipe.execute()

        return jobs_without_dependencies + jobs_with_unmet_dependencies + jobs_with_met_dependencies

    def run_job(self, job: Job) -> Job:
        """Run the job

        Args:
            job (Job): The job to run

        Returns:
            Job: _description_
        """
        job.perform()
        job.ended_at = now()
        result_ttl = job.get_result_ttl(default_ttl=DEFAULT_RESULT_TTL)
        with self.connection.pipeline() as pipeline:
            job._handle_success(result_ttl=result_ttl, pipeline=pipeline, worker_name='')
            job.cleanup(result_ttl, pipeline=pipeline)
            pipeline.execute()
        return job

    @classmethod
    def parse_args(cls, f: FunctionReferenceType, *args, **kwargs):
        """
        Parses arguments passed to `queue.enqueue()` and `queue.enqueue_at()`

        The function argument `f` may be any of the following:

        * A reference to a function
        * A reference to an object's instance method
        * A string, representing the location of a function (must be
          meaningful to the import context of the workers)

        Args:
            f (FunctionReferenceType): The function reference
            args (*args): function args
            kwargs (**kwargs): function kwargs
        """
        if not isinstance(f, str) and f.__module__ == '__main__':
            raise ValueError('Functions from the __main__ module cannot be processed by workers')

        # Detect explicit invocations, i.e. of the form:
        #     q.enqueue(foo, args=(1, 2), kwargs={'a': 1}, job_timeout=30)
        timeout = kwargs.pop('job_timeout', None)
        description = kwargs.pop('description', None)
        result_ttl = kwargs.pop('result_ttl', None)
        ttl = kwargs.pop('ttl', None)
        failure_ttl = kwargs.pop('failure_ttl', None)
        depends_on = kwargs.pop('depends_on', None)
        job_id = kwargs.pop('job_id', None)
        at_front = kwargs.pop('at_front', False)
        meta = kwargs.pop('meta', None)
        retry = kwargs.pop('retry', None)
        repeat = kwargs.pop('repeat', None)
        on_success = kwargs.pop('on_success', None)
        on_failure = kwargs.pop('on_failure', None)
        on_stopped = kwargs.pop('on_stopped', None)
        rate_limit = kwargs.pop('rate_limit', None)
        webhooks = kwargs.pop('webhooks', None)
        pipeline = kwargs.pop('pipeline', None)
        unique = kwargs.pop('unique', False)

        if 'args' in kwargs or 'kwargs' in kwargs:
            assert args == (), 'Extra positional arguments cannot be used when using explicit args and kwargs'  # noqa
            args = kwargs.pop('args', None)
            kwargs = kwargs.pop('kwargs', None)

        return EnqueueArgs(
            f,
            timeout,
            description,
            result_ttl,
            ttl,
            failure_ttl,
            depends_on,
            job_id,
            at_front,
            meta,
            retry,
            repeat,
            on_success,
            on_failure,
            on_stopped,
            rate_limit,
            pipeline,
            unique,
            args,
            kwargs,
            webhooks,
        )

    def enqueue(self, f: FunctionReferenceType, *args, **kwargs) -> Job:
        """Creates a job to represent the delayed function call and enqueues it.
        Receives the same parameters accepted by the `enqueue_call` method.

        Args:
            f (FunctionReferenceType): The function reference
            args (*args): function args
            kwargs (**kwargs): function kwargs

        Returns:
            job (Job): The created Job
        """
        (
            f,
            timeout,
            description,
            result_ttl,
            ttl,
            failure_ttl,
            depends_on,
            job_id,
            at_front,
            meta,
            retry,
            repeat,
            on_success,
            on_failure,
            on_stopped,
            rate_limit,
            pipeline,
            unique,
            args,
            kwargs,
            webhooks,
        ) = Queue.parse_args(f, *args, **kwargs)

        return self.enqueue_call(
            func=f,
            args=args,
            kwargs=kwargs,
            timeout=timeout,
            result_ttl=result_ttl,
            ttl=ttl,
            failure_ttl=failure_ttl,
            description=description,
            depends_on=depends_on,
            job_id=job_id,
            at_front=at_front,
            meta=meta,
            retry=retry,
            repeat=repeat,
            on_success=on_success,
            on_failure=on_failure,
            on_stopped=on_stopped,
            rate_limit=rate_limit,
            webhooks=webhooks,
            pipeline=pipeline,
            unique=unique,
        )

    def enqueue_at(self, datetime: datetime, f, *args, **kwargs):
        """Schedules a job to be enqueued at specified time

        Args:
            datetime (datetime): _description_
            f (_type_): _description_

        Returns:
            _type_: _description_
        """
        (
            f,
            timeout,
            description,
            result_ttl,
            ttl,
            failure_ttl,
            depends_on,
            job_id,
            at_front,
            meta,
            retry,
            repeat,
            on_success,
            on_failure,
            on_stopped,
            rate_limit,
            pipeline,
            unique,
            args,
            kwargs,
            webhooks,
        ) = Queue.parse_args(f, *args, **kwargs)
        job = self.create_job(
            f,
            status=JobStatus.SCHEDULED,
            args=args,
            kwargs=kwargs,
            timeout=timeout,
            result_ttl=result_ttl,
            ttl=ttl,
            failure_ttl=failure_ttl,
            description=description,
            depends_on=depends_on,
            job_id=job_id,
            meta=meta,
            retry=retry,
            repeat=repeat,
            on_success=on_success,
            on_failure=on_failure,
            on_stopped=on_stopped,
            rate_limit=rate_limit,
            webhooks=webhooks,
        )
        if at_front:
            job.enqueue_at_front = True
        return self.schedule_job(job, datetime, pipeline=pipeline, unique=unique)

    def schedule_job(self, job: Job, datetime: datetime, pipeline: Pipeline | None = None, unique: bool = False) -> Job:
        """Puts job on ScheduledJobRegistry

        Args:
            job (Job): The job to schedule
            datetime (datetime): The scheduled execution time
            pipeline (Optional[Pipeline], optional): The Redis pipeline to use. Defaults to None.
            unique (bool, optional): If True, raises DuplicateJobError if a job with the same ID exists.
                Defaults to False.

        Returns:
            Job: The scheduled job

        Raises:
            ValueError: If the job is rate limited and its class or this queue's class overrides
                the default key prefix
        """
        from .registry import ScheduledJobRegistry

        self._check_rate_limit_namespace(job)
        registry = ScheduledJobRegistry(queue=self)

        if unique and not job._id:
            raise ValueError('unique=True requires an explicit job_id')
        if unique:
            job._status = JobStatus.SCHEDULED
            # Atomic: check uniqueness, save job, add to scheduled registry, register queue
            schedule_unique_job(self.connection, self.key, registry.key, job, datetime)
            return job

        pipe = pipeline if pipeline is not None else self.connection.pipeline()

        # Add Queue key set
        pipe.sadd(self.redis_queues_keys, self.key)
        self._persist_job(job, pipe, status=JobStatus.SCHEDULED)

        registry.schedule(job, datetime, pipeline=pipe)
        if pipeline is None:
            pipe.execute()
        return job

    def enqueue_in(self, time_delta: timedelta, func: FunctionReferenceType, *args, **kwargs) -> Job:
        """Schedules a job to be executed in a given `timedelta` object

        Args:
            time_delta (timedelta): The timedelta object
            func (FunctionReferenceType): The function reference

        Returns:
            job (Job): The enqueued Job
        """
        return self.enqueue_at(now() + time_delta, func, *args, **kwargs)

    def enqueue_job(
        self, job: Job, pipeline: Pipeline | None = None, at_front: bool = False, unique: bool = False
    ) -> Job:
        """Enqueues a job for delayed execution checking dependencies.

        Args:
            job (Job): The job to enqueue
            pipeline (Optional[Pipeline], optional): The Redis pipeline to use. Defaults to None.
            at_front (bool, optional): Whether should enqueue at the front of the queue. Defaults to False.
            unique (bool, optional): If True, raises DuplicateJobError if a job with the same ID exists.
                Defaults to False.

        Returns:
            Job: The enqueued job

        Raises:
            ValueError: If unique=True and job has dependencies
            ValueError: If the job is rate limited and its class or this queue's class overrides
                the default key prefix
            ValueError: If the job is rate limited and a pipeline is given
        """
        self._check_rate_limit_namespace(job)
        if unique and not job._id:
            raise ValueError('unique=True requires an explicit job_id')
        if unique and job._dependency_ids:
            raise ValueError('unique=True is not supported with job dependencies')
        if unique and job.has_rate_limit:
            raise ValueError('unique=True is not supported with rate-limited jobs')
        if job.has_rate_limit and not self._is_async:
            raise ValueError('rate_limit is not supported on synchronous queues (is_async=False)')
        # Promotion would run inside the caller's pipeline, so a later save of the returned
        # job on that pipeline would overwrite the promoted status.
        if job.has_rate_limit and pipeline is not None:
            raise ValueError('rate-limited jobs cannot be enqueued with a pipeline')

        job.origin = self.name
        job = self.setup_dependencies(job, pipeline=pipeline)
        # Add Queue key set
        pipe = pipeline if pipeline is not None else self.connection.pipeline()
        pipe.sadd(self.redis_queues_keys, self.key)
        if pipeline is None:
            pipe.execute()
        # If we do not depend on an unfinished job, enqueue the job.
        if job.get_status(refresh=False) != JobStatus.DEFERRED:
            if job.has_rate_limit:
                return self._enqueue_rate_limited_job(job, pipeline=pipeline, at_front=at_front)
            return self._enqueue_job(job, pipeline=pipeline, at_front=at_front, unique=unique)
        return job

    def _check_rate_limit_namespace(self, job: Job) -> None:
        """Rejects a rate-limited job whose class or this queue's class overrides the default
        key prefix, since the rate limiter builds keys from the base `Job` and `Queue` prefixes."""
        if job.has_rate_limit and (
            job.redis_job_namespace_prefix != Job.redis_job_namespace_prefix
            or self.redis_queue_namespace_prefix != Queue.redis_queue_namespace_prefix
        ):
            raise ValueError('rate_limit is not supported with custom job or queue key prefixes')

    def _enqueue_rate_limited_job(self, job: Job, pipeline: Pipeline | None = None, at_front: bool = False) -> Job:
        """Enqueue a job through the rate limit registry.

        Saves the job as rate_limited and adds it to the waiting set atomically, then fills
        free slots with waiting jobs, oldest first. Without a free slot, the job keeps waiting.

        Args:
            job (Job): The job to enqueue (must have rate_limit_key and rate_limit_concurrency set)
            pipeline (Optional[Pipeline]): If given, the job's writes and promotion are queued on it
                and run when it executes. Don't save the job on it afterwards; that would overwrite
                the promoted status.
            at_front (bool): Whether the job should be pushed to the front of its queue when
                promoted. Persisted on the job so the (possibly later, cross-worker) promotion
                can honor it.

        Returns:
            Job: The job
        """
        job.redis_server_version = self.get_redis_server_version()
        job.origin = self.name
        if job.timeout is None:
            job.timeout = self._default_timeout

        assert job.rate_limit_concurrency

        registry = RateLimitRegistry.from_job(job)
        job._status = JobStatus.RATE_LIMITED
        if at_front:
            job.enqueue_at_front = True
        pipe = pipeline if pipeline is not None else self.connection.pipeline()
        registry.register(job.rate_limit_concurrency, pipe)
        job.save(pipeline=pipe)
        job.cleanup(ttl=job.ttl, pipeline=pipe)
        registry.add_to_rate_limited(job.id, pipe)

        if pipeline is not None:
            registry.acquire_and_enqueue(job.rate_limit_concurrency, pipeline=pipe)
            return job

        pipe.execute()
        enqueued_at = now()
        promoted_job_ids = registry.acquire_and_enqueue(job.rate_limit_concurrency, enqueued_at=enqueued_at)
        if job.id in promoted_job_ids:
            job._status = JobStatus.QUEUED
            job.enqueued_at = enqueued_at
        return job

    def _enqueue_job(
        self, job: Job, pipeline: Pipeline | None = None, at_front: bool = False, unique: bool = False
    ) -> Job:
        """Enqueues a job for delayed execution without checking dependencies.

        If Queue is instantiated with is_async=False, job is executed immediately.

        Args:
            job (Job): The job to enqueue
            pipeline (Optional[Pipeline], optional): The Redis pipeline to use. Defaults to None.
            at_front (bool, optional): Whether should enqueue at the front of the queue. Defaults to False.
            unique (bool, optional): If True, raises DuplicateJobError if a job with the same ID exists.
                Defaults to False.

        Returns:
            Job: The enqueued job
        """
        if self._is_async:
            return self._enqueue_async_job(job, pipeline=pipeline, at_front=at_front, unique=unique)
        else:
            return self._enqueue_sync_job(job, pipeline=pipeline, unique=unique)

    def _prepare_for_queue(self, job: Job) -> None:
        """Prepare a job for enqueueing by setting its metadata.

        This sets common job properties (redis_server_version, origin, enqueued_at, timeout, status)
        without persisting to Redis.

        Args:
            job (Job): The job to prepare
        """
        job.redis_server_version = self.get_redis_server_version()
        job.origin = self.name
        job.enqueued_at = now()
        if job.timeout is None:
            job.timeout = self._default_timeout
        job._status = JobStatus.QUEUED

    def _persist_job(self, job: Job, pipeline: Pipeline, status: JobStatus = JobStatus.QUEUED) -> None:
        """Persist a job to Redis.

        This saves the job data and performs cleanup.

        Args:
            job (Job): The job to save
            pipeline (Pipeline): The Redis pipeline to use
            status (JobStatus): The job status to set. Defaults to JobStatus.QUEUED.
        """
        job.set_status(status, pipeline=pipeline)
        job.save(pipeline=pipeline)
        job.cleanup(ttl=job.ttl, pipeline=pipeline)

    def _enqueue_async_job(
        self, job: Job, pipeline: Pipeline | None = None, at_front: bool = False, unique: bool = False
    ) -> Job:
        """Enqueues a job for async (delayed) execution.

        Args:
            job (Job): The job to enqueue
            pipeline (Optional[Pipeline], optional): The Redis pipeline to use. Defaults to None.
            at_front (bool, optional): Whether should enqueue at the front of the queue. Defaults to False.
            unique (bool, optional): If True, raises DuplicateJobError if a job with the same ID exists.
                Defaults to False.

        Returns:
            Job: The enqueued job
        """
        self.log.debug('Enqueueing job %s to queue %s (at_front=%s)', job.id, self.name, at_front)

        is_deferred = job.get_status(refresh=False) == JobStatus.DEFERRED
        self._prepare_for_queue(job)

        if unique:
            # Use atomic Lua script for unique enqueue (check + save + push)
            # Note: pipeline is ignored when unique=True because the Lua script is atomic
            save_unique_job(self.connection, self.key, job, at_front=at_front)
        else:
            pipe = pipeline if pipeline is not None else self.connection.pipeline()

            if is_deferred:
                self.deferred_job_registry.remove(job, pipeline=pipe)
            self._persist_job(job, pipe)
            self.push_job_id(job.id, pipeline=pipe, at_front=at_front)

            if pipeline is None:
                pipe.execute()

        return job

    def _enqueue_sync_job(self, job: Job, pipeline: Pipeline | None = None, unique: bool = False) -> Job:
        """Enqueues and immediately executes a job synchronously.

        Args:
            job (Job): The job to enqueue and execute
            pipeline (Optional[Pipeline], optional): The Redis pipeline to use. Defaults to None.
            unique (bool, optional): If True, raises DuplicateJobError if a job with the same ID exists.
                Defaults to False.

        Returns:
            Job: The executed job
        """
        self.log.debug('Enqueueing job %s to queue %s (sync execution)', job.id, self.name)

        is_deferred = job.get_status(refresh=False) == JobStatus.DEFERRED
        self._prepare_for_queue(job)

        if unique:
            # Use atomic Lua script for unique check and save (without pushing to queue)
            save_unique_job(self.connection, self.key, job, enqueue=False)
        else:
            pipe = pipeline if pipeline is not None else self.connection.pipeline()

            if is_deferred:
                self.deferred_job_registry.remove(job, pipeline=pipe)
            self._persist_job(job, pipe)

            if pipeline is None:
                pipe.execute()

        job = self.run_sync(job)

        return job

    def run_sync(self, job: Job) -> Job:
        """Run a job synchronously, meaning on the same process the method was called.

        Args:
            job (Job): The job to run

        Returns:
            Job: The job instance
        """
        with self.connection.pipeline() as pipeline:
            job.prepare_for_execution('sync', pipeline)

        try:
            job = self.run_job(job)
        except:  # noqa
            with self.connection.pipeline() as pipeline:
                exc_string = format_exc_info(sys.exc_info())
                record_job_failure(job, exc_string, pipeline)
                pipeline.execute()

            execute_failure_callback(job, self.death_penalty_class, *sys.exc_info())
            job.send_webhooks(JobStatus.FAILED, exc_string=exc_string)
        else:
            execute_success_callback(job, self.death_penalty_class, job._result)
            job.send_webhooks(JobStatus.FINISHED)

        return job

    def move_dependents_to_ready(
        self,
        job: Job,
        pipeline: Pipeline | None = None,
        exclude_job_id: str | None = None,
        refresh_job_status: bool = True,
    ) -> dict[str, list[str]]:
        """Move the given job's eligible dependents from deferred to ready.

        Move dependents whose dependencies are met (and which aren't canceled) to
        `ReadyJobRegistry` via `register_jobs`. Usually followed up by
        `enqueue_ready_jobs_by_queue` to enqueue the dependents.

        When `pipeline` is `None` this method runs its own WATCH/MULTI/EXEC. A passed
        pipeline must already be in WATCH mode (this method reads before appending its
        writes); the caller is responsible for EXEC.

        Args:
            job: The job whose dependents to process.
            pipeline: Optional caller-owned pipeline.
            exclude_job_id: Skip a specific dependent id.
            refresh_job_status: Whether to refresh dependent status during dependency check.

        Returns:
            Map of origin queue name → list of dependent job ids that were moved to ready.
        """
        from .registry import ReadyJobRegistry

        pipe = pipeline if pipeline is not None else self.connection.pipeline()
        if pipeline is not None and not pipeline.watching:
            raise ValueError('move_dependents_to_ready() requires a watched pipeline when pipeline is provided')

        dependents_key = job.dependents_key

        job_ids_by_queue_name: dict[str, list[str]] = {}

        while True:
            try:
                # if a pipeline is passed, the caller is responsible for calling WATCH
                # to ensure all jobs are enqueued
                if pipeline is None:
                    pipe.watch(dependents_key)

                dependent_job_ids = {as_text(_id) for _id in pipe.smembers(dependents_key)}  # type: ignore[attr-defined]

                # There's no dependents
                if not dependent_job_ids:
                    break

                jobs_to_mark_ready = [
                    dependent_job
                    for dependent_job in self.job_class.fetch_many(
                        dependent_job_ids, connection=self.connection, serializer=self.serializer
                    )
                    if dependent_job
                    and dependent_job.dependencies_are_met(
                        parent_job=job,
                        pipeline=pipe,
                        exclude_job_id=exclude_job_id,
                        refresh_job_status=refresh_job_status,
                    )
                    and dependent_job.get_status(refresh=False) != JobStatus.CANCELED
                ]

                pipe.multi()

                if not jobs_to_mark_ready:
                    break

                self.log.debug(
                    'Moving %d dependent jobs to ready for job %s: %s',
                    len(jobs_to_mark_ready),
                    job.id,
                    [j.id for j in jobs_to_mark_ready],
                )

                # Group dependents by their origin queue so each lands in the correct
                # ReadyJobRegistry. Reset accumulator on each loop iteration so a
                # WatchError-induced retry doesn't double-count.
                job_ids_by_queue_name = {}
                grouped: dict[str, list[Job]] = defaultdict(list)
                for dependent in jobs_to_mark_ready:
                    grouped[dependent.origin].append(dependent)

                for queue_name, group in grouped.items():
                    target_registry = ReadyJobRegistry(
                        name=queue_name,
                        connection=self.connection,
                        job_class=self.job_class,
                        serializer=self.serializer,
                    )
                    target_registry.register_jobs(group, pipeline=pipe)
                    job_ids_by_queue_name[queue_name] = [j.id for j in group]

                # Only delete dependents_key if all dependents have been moved to ready
                if len(jobs_to_mark_ready) == len(dependent_job_ids):
                    pipe.delete(dependents_key)
                else:
                    ready_job_ids = [j.id for j in jobs_to_mark_ready]
                    pipe.srem(dependents_key, *ready_job_ids)

                if pipeline is None:
                    pipe.execute()
                break
            except WatchError:
                if pipeline is None:
                    job_ids_by_queue_name = {}
                    continue
                else:
                    # if the pipeline comes from the caller, we re-raise the
                    # exception as it it the responsibility of the caller to
                    # handle it
                    raise

        return job_ids_by_queue_name

    def enqueue_ready_jobs_by_queue(self, job_ids_by_queue_name: dict[str, list[str]]) -> None:
        """Enqueue ready dependents onto their origin queues.

        Args:
            job_ids_by_queue_name: Map of origin queue name → list of ready job ids.
        """
        for queue_name, ids in job_ids_by_queue_name.items():
            try:
                target_queue = self.__class__(
                    name=queue_name,
                    connection=self.connection,
                    job_class=self.job_class,
                    serializer=self.serializer,
                )
                target_queue.ready_job_registry.enqueue_jobs(ids)
            except Exception:
                self.log.exception(
                    'Failed to drain ready dependents for queue %s; leaving for ReadyJobRegistry.cleanup()',
                    queue_name,
                )

    def enqueue_dependents(
        self,
        job: Job,
        exclude_job_id: str | None = None,
        refresh_job_status: bool = True,
    ) -> dict[str, list[str]]:
        """Move the given job's eligible dependents to ready and enqueue them.

        Args:
            job: The job whose dependents to process.
            exclude_job_id: Skip a specific dependent id.
            refresh_job_status: Whether to refresh dependent status during dependency check.

        Returns:
            Map of origin queue name → list of dependent job ids that were moved to ready.
        """
        job_ids_by_queue_name = self.move_dependents_to_ready(
            job, exclude_job_id=exclude_job_id, refresh_job_status=refresh_job_status
        )
        self.enqueue_ready_jobs_by_queue(job_ids_by_queue_name)
        return job_ids_by_queue_name

    def pop_job_id(self) -> str | None:
        """Pops a given job ID from this Redis queue.

        Returns:
            job_id (str): The job id
        """
        return as_text(self.connection.lpop(self.key))

    # The queue_keys type is Sequence[str] instead of Iterable[str]
    # because we loop over it twice, and we don't want user to pass a generator.
    @classmethod
    def lpop(cls, queue_keys: Sequence[str], timeout: int | None, connection: Redis | None = None):
        """Helper method to abstract away from some Redis API details
        where LPOP accepts only a single key, whereas BLPOP
        accepts multiple.  So if we want the non-blocking LPOP, we need to
        iterate over all queues, do individual LPOPs, and return the result.

        Until Redis receives a specific method for this, we'll have to wrap it
        this way.

        The timeout parameter is interpreted as follows:
            None - non-blocking (return immediately)
             > 0 - maximum number of seconds to block

        Args:
            queue_keys (Sequence[str]): _description_
            timeout (Optional[int]): _description_
            connection (Optional[Redis], optional): _description_. Defaults to None.

        Raises:
            ValueError: If timeout of 0 was passed
            DequeueTimeout: BLPOP Timeout

        Returns:
            _type_: _description_
        """
        if timeout is not None:  # blocking variant
            if timeout == 0:
                raise ValueError('RQ does not support indefinite timeouts. Please pick a timeout value > 0')
            colored_queues = ', '.join(map(str, [green(str(queue)) for queue in queue_keys]))
            logger.debug('Starting BLPOP operation for queues %s with timeout of %d', colored_queues, timeout)
            assert connection
            result = connection.blpop(queue_keys, timeout)
            if result is None:
                logger.debug('BLPOP timeout, no jobs found on queues %s', colored_queues)
                raise DequeueTimeout(timeout, queue_keys)
            queue_key, job_id = result
            return queue_key, job_id
        else:  # non-blocking variant
            for queue_key in queue_keys:
                assert connection
                blob = connection.lpop(queue_key)
                if blob is not None:
                    return queue_key, blob
            return None

    @classmethod
    def lmove(cls, connection: Redis, queue_key: str, timeout: int | None):
        """Similar to lpop, but accepts only a single queue key and immediately pushes
        the result to an intermediate queue.
        """
        intermediate_queue = IntermediateQueue(queue_key, connection)
        if timeout is not None:  # blocking variant
            if timeout == 0:
                raise ValueError('RQ does not support indefinite timeouts. Please pick a timeout value > 0')
            colored_queue = green(queue_key)
            logger.debug(f'Starting BLMOVE operation for {colored_queue} with timeout of {timeout}')
            result: Any | None = connection.blmove(queue_key, intermediate_queue.key, timeout)
            if result is None:
                logger.debug(f'BLMOVE timeout, no jobs found on {colored_queue}')
                raise DequeueTimeout(timeout, queue_key)
            return queue_key, result
        else:  # non-blocking variant
            result = cast(Any | None, connection.lmove(queue_key, intermediate_queue.key))
            if result is not None:
                return queue_key, result
            return None

    @classmethod
    def dequeue_any(
        cls,
        queues: Iterable[Queue],
        timeout: int | None,
        connection: Redis,
        job_class: type[Job] | None = None,
        serializer: Serializer | str | None = None,
        death_penalty_class: type[BaseDeathPenalty] | None = None,
    ) -> tuple[Job, Queue] | None:
        """Class method returning the job_class instance at the front of the given
        set of Queues, where the order of the queues is important.

        When all of the Queues are empty, depending on the `timeout` argument,
        either blocks execution of this function for the duration of the
        timeout or until new messages arrive on any of the queues, or returns
        None.

        See the documentation of cls.lpop for the interpretation of timeout.

        Args:
            queues (Iterable[Queue]): Iterable of queue objects
            timeout (Optional[int]): Timeout for the LPOP
            connection (Optional[Redis], optional): Redis Connection. Defaults to None.
            job_class (Optional[Type[Job]], optional): The job class. Defaults to None.
            serializer (Optional[Union[Serializer, str]], optional): Serializer to use. Defaults to None.
            death_penalty_class (Optional[Type[BaseDeathPenalty]], optional): The death penalty class. Defaults to None.

        Raises:
            e: Any exception

        Returns:
            job, queue (Tuple[Job, Queue]): A tuple of Job, Queue
        """
        queue_keys = [queue.key for queue in queues]
        while True:
            if len(queue_keys) == 1 and get_version(connection) >= (6, 2, 0):
                result = cls.lmove(connection, queue_keys[0], timeout)
            else:
                result = cls.lpop(queue_keys, timeout, connection=connection)
            if result is None:
                return None
            queue_key, job_id = map(as_text, result)
            job_fetch_result = cls._fetch_dequeued_job(
                connection,
                queue_key,
                job_id,
                job_class=job_class,
                serializer=serializer,
                death_penalty_class=death_penalty_class,
            )
            if job_fetch_result is None:
                continue
            return job_fetch_result

    @classmethod
    def _fetch_dequeued_job(
        cls,
        connection: Redis,
        queue_key: str,
        job_id: str,
        job_class: type[Job] | None = None,
        serializer: Serializer | str | None = None,
        death_penalty_class: type[BaseDeathPenalty] | None = None,
    ) -> tuple[Job, Queue] | None:
        """Post-pop processing shared by `dequeue_any` and the async worker:
        rebuild the Queue from its key and fetch the Job. Returns None when the
        job hash no longer exists (caller should dequeue again); attaches
        job_id/queue metadata to other fetch errors.
        """
        job_cls: type[Job] = backend_class(cls, 'job_class', override=job_class)
        queue = cls.from_queue_key(
            queue_key,
            connection=connection,
            job_class=job_cls,
            serializer=serializer,
            death_penalty_class=death_penalty_class,
        )
        try:
            job = job_cls.fetch(job_id, connection=connection, serializer=serializer)
        except NoSuchJobError:
            # Silently pass on jobs that don't exist (anymore)
            return None
        except Exception as e:
            # Attach queue information on the exception for improved error
            # reporting
            e.job_id = job_id  # type: ignore[attr-defined]
            e.queue = queue  # type: ignore[attr-defined]
            raise e
        return job, queue

    # Total ordering definition (the rest of the required Python methods are
    # auto-generated by the @total_ordering decorator)
    def __eq__(self, other):  # noqa
        if not isinstance(other, Queue):
            raise TypeError('Cannot compare queues to other objects')
        return self.name == other.name

    def __lt__(self, other):
        if not isinstance(other, Queue):
            raise TypeError('Cannot compare queues to other objects')
        return self.name < other.name

    def __hash__(self):  # pragma: no cover
        return hash(self.name)

    def __repr__(self):  # noqa  # pragma: no cover
        return f'{self.__class__.__name__}({self.name!r})'

    def __str__(self):
        return f'<{self.__class__.__name__} {self.name}>'
